class Employee{
	String name;
	int empID;
	double salary;


	Employee(String name, int empID, double salary){
	this.name = name;
	this.empID = empID;
	this.salary = salary;
}

void increasSalary(double amount){
	salary +=amount;
	System.out.println("Salary after increament of "+amount+" is : "+salary);
}

void calculateAnnualSalary(){
	salary = salary*12;
	System.out.println("The annual salary is : "+salary);
}

void displayDetails(){
	System.out.println("Employee name : "+name+" | ID : "+empID+" | Current Salary : "+salary);
}
public static void main(String[] args){
	Employee e1 = new Employee("Hamadullah", 56, 5000.0);
	e1.displayDetails();
	e1.increasSalary(2000.0);
	e1.calculateAnnualSalary();
}
}