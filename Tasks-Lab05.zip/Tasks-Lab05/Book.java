class Book{
	String title;
	String author;
	boolean available;

Book(String title, String author){
	this.title = title;
	this.author = author;
	this.available = true;
}

//Method for borrow Book.
void borrowBook(){
if(available){
	available = false;
	System.out.println("You have successfully borrowed: " + title);
}
else{
	System.out.println("Not available");
}
}

//Method for return a book.
void returnBook(){
	available = true;
}

void displayBook(){
	if(available){
		System.out.println("Title : "+title+" | Author : "+author+" is  available.");
}
else{
	System.out.println("Title : "+title+" | Author : "+author+" is not available.");
}		
}

public static void main(String[] args){
 Book b1 = new Book("The Book", "Alex Martin");
 	b1.displayBook();

	b1.borrowBook();
	b1.displayBook();

	b1.returnBook();
	b1.displayBook();

}
}